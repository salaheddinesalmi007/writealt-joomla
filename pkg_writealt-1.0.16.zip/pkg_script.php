<?php

/**
 * @package     WriteAlt
 * @subpackage  pkg_writealt
 *
 * @copyright   (C) 2026 WriteAlt <https://writealt.com>
 * @license     GNU General Public License version 2 or later; see LICENSE
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerScript;

/**
 * Enables the article integration after the package installs its child extensions.
 */
class PkgWritealtInstallerScript extends InstallerScript
{
    public function postflight($type, $parent)
    {
        if ($type === 'uninstall') {
            return;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('content'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('writealt'));

        $db->setQuery($query)->execute();
    }
}
