<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerScript;

/**
 * Enables the article integration after the package installs its child extensions.
 */
class PkgWritealtInstallerScript extends InstallerScript
{
    public function postflight($type, $parent)
    {
        if ($type === 'uninstall') {
            return;
        }

        $db = Factory::getDbo();
        $query = $db->getQuery(true)
            ->update($db->quoteName('#__extensions'))
            ->set($db->quoteName('enabled') . ' = 1')
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('content'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('writealt'));

        $db->setQuery($query)->execute();
    }
}
